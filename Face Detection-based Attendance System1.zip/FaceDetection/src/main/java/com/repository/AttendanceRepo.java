package com.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Entity.Attendance;

public interface AttendanceRepo extends JpaRepository<Attendance, Long> {
    Attendance findByEmpIdAndDate(String empId, String date);
    List<Attendance> findByEmpId(String empId);
    List<Attendance> findByDate(String date);
}

