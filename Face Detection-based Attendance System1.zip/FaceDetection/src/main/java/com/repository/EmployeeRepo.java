package com.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Entity.Employee;
public interface EmployeeRepo extends JpaRepository<Employee, Long> {
    Employee findByIdAndRole(Long id, String role); // ✅ Long
}
