package com.controller;


import com.Entity.Attendance;
import com.Entity.Employee;
import com.repository.AttendanceRepo;
import com.repository.EmployeeRepo;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
public class TaskController {

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private AttendanceRepo attendanceRepo;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> payload) {
        try {
            String name = payload.get("name");
            String base64Image = payload.get("image");
            String role = payload.get("role"); 

            if (name == null || base64Image == null || role == null) {
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Missing fields"));
            }

            String filename = name.replaceAll("\\s+", "_") + "_" + System.currentTimeMillis() + ".jpg";
            Path folder = Paths.get("static/faces");
            Path path = folder.resolve(filename);

            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            if (!Files.exists(folder)) Files.createDirectories(folder);
            Files.write(path, imageBytes);

            Employee emp = new Employee();
            emp.setName(name);
            emp.setImagePath(filename);
            emp.setRole(role); 

            Employee saved = employeeRepo.save(emp);

            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Registered successfully",
                "empId", saved.getId().toString()
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("success", false, "message", "Something went wrong"));
        }
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> payload) {
        String userId = payload.get("userId");
        String role = payload.get("role");

        try {
            Long id = Long.parseLong(userId);
            Employee emp = employeeRepo.findByIdAndRole(id, role);

            if (emp != null) {
                if (role.equalsIgnoreCase("Admin")) {
                    return Map.of("success", true, "redirect", "/admin-dashboard.html");
                } else {
                    return Map.of("success", true, "redirect", "/employee-dashboard.html?empId=" + emp.getId());
                }
            } else {
                return Map.of("success", false, "message", "Invalid ID or Role");
            }
        } catch (NumberFormatException e) {
            return Map.of("success", false, "message", "Employee ID must be a number");
        } catch (Exception e) {
            return Map.of("success", false, "message", "Server error");
        }
    }


    @PostMapping("/scan-face")
    public Map<String, String> scanFace(@RequestBody Map<String, String> payload) {
        String base64Image = payload.get("image").split(",")[1];
        String empIdStr = payload.get("empId");

        Long empId;
        try {
            empId = Long.parseLong(empIdStr);
        } catch (NumberFormatException e) {
            return Map.of("message", " Invalid employee ID");
        }

        Optional<Employee> employeeOpt = employeeRepo.findById(empId);
        if (employeeOpt.isPresent()) {
            String empIdStrFinal = empId.toString(); 
            String date = LocalDate.now().toString();
            Attendance att = attendanceRepo.findByEmpIdAndDate(empIdStrFinal, date);

            if (att == null) {
                Attendance a = new Attendance();
                a.setEmpId(empIdStrFinal);
                a.setDate(date);
                a.setEntryTime(LocalTime.now().toString());
                attendanceRepo.save(a);
                return Map.of("message", " Entry marked");
            } else if (att.getExitTime() == null) {
                att.setExitTime(LocalTime.now().toString());
                attendanceRepo.save(att);
                return Map.of("message", "Exit marked");
            } else {
                return Map.of("message", " Already marked for today");
            }
        }

        return Map.of("message", " Employee not found");
    }

    @GetMapping("/employee-history/{empId}")
    public ResponseEntity<List<Attendance>> getHistory(@PathVariable("empId") String empId) {
 
        List<Attendance> history = attendanceRepo.findByEmpId(empId);
        return ResponseEntity.ok(history);
        }
    

    @GetMapping("/admin/attendance/by-date")
    public List<Attendance> filter(@RequestParam("date") String date) {
 
        return attendanceRepo.findByDate(date);
    }

    @GetMapping("/admin/attendance")
    public List<Attendance> all() {
        return attendanceRepo.findAll();
    }
}
